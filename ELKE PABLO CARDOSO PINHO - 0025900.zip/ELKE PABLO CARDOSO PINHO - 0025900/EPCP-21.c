//EPCP-21.c
#include<stdio.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL, "");
	
	printf("\n*********************************************************");
	printf("\n*ALUNO: ELKE PABLO CARDOSO PINHO - 0025900*");
	printf("\n*PROGRAMA EPCP - 21 - N�mero positivo ou negativo*");
	printf("\n*********************************************************");
	
	int num;
	
	printf("Digite o n�mero: ");
	scanf("%d", &num);
	
	if(num>0){
		printf("O n�mero � positivo.");
	}
	else if(num<0){
		printf("O n�mero � negativo.");
	}
	else{
		printf("O n�mero � 0.");
	}
	return 0;
}
