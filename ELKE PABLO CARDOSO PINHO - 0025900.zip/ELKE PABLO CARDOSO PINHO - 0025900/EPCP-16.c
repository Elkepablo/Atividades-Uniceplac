//EPCP-16.c
#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

    printf("\n*********************************************************");
	printf("\n*ALUNO: ELKE PABLO CARDOSO PINHO - 0025900*");
	printf("\n*PROGRAMA EPCP - 16 - M�ltiplo de 3 e/ou 5*");
	printf("\n*********************************************************");

int main(){
setlocale (LC_ALL,"");

int numeropedido;

printf("Digite o n�mero do pedido: ");
scanf("%d", &numeropedido);

if(numeropedido %3==0){
	printf("Parab�ns, voc� ganhou um refrigerante!\n");
}
if(numeropedido %5==0){
	printf("Parab�ns, voc� ganhou uma sobremesa!\n");
}
if(numeropedido %2==0){
	printf("Parab�ns, voc� ganhou dois brindes!\n");
}
return 0;
}
