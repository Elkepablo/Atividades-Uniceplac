//EPCP-23
#include<stdio.h>
#include<locale.h>

int main (){
	setlocale(LC_ALL, "");
	
	printf("\n*********************************************************");
	printf("\n*ALUNO: ELKE PABLO CARDOSO PINHO - 0025900*");
	printf("\n*PROGRAMA EPCP - 23 - Maior de dois n�meros*");
	printf("\n*********************************************************");
	
	int n1, n2;
	
	printf("Digite a primeira pontua��o: ");
	scanf("%d", &n1);
	
	printf("Digite a segunda pontia��o: ");
	scanf("%d", &n2);
	
	if(n1>n2){
		printf("A pontua��o %d � maior.", n1);
	}
	else if(n2>n1){
		printf("A pontua��o %d � maior.", n2);
	}
	else{
		printf("As pontua��es s�o iguais.");
	}
	return 0;
}
