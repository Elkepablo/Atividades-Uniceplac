//EPCP-34
#include<stdio.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL, "");
	
	printf("\n*********************************************************");
	printf("\n*ALUNO: ELKE PABLO CARDOSO PINHO - 0025900*");
	printf("\n*PROGRAMA EPCP - 34 - Verificar se um n�mero � primo*");
	printf("\n*********************************************************");
	
	
	int i, num, primo = 1;
	
	printf("Digite um n�mero: ");
	scanf("%d", &num);
	
	if(num == 0 || num == 1){
		printf("O n�mero n�o � primo!", num);
	}
	else if(num == 2){
		printf("O n�mero � primo!");
	}
	else{
		for(i=2; i<num; i++){
			if(num % i == 0){
				primo = 0;
				printf("O n�mero n�o � primo!");
				break;
			}
			else{
				printf("O n�mero � primo!");
				break;
			}
		}
	}
	return 0;
}
