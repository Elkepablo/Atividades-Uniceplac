//EPCP-42
#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL, "");
	
	printf("\n*********************************************************");
	printf("\n*ALUNO: ELKE PABLO CARDOSO PINHO - 0025900*");
	printf("\n*PROGRAMA EPCP - 42 - Quantidade de n�meros �mpares digitados*");
	printf("\n*********************************************************");
	
	int num, i=0, impares=0;
	
	while (i<10){
	printf("Digite um n�mero: ");
	scanf("%d", &num);

if (num % 2 != 0){
	impares++;
}
i++;
}
printf("Quantidade de n�meros �mpares s�o: %d\n", impares);

return 0;
}
